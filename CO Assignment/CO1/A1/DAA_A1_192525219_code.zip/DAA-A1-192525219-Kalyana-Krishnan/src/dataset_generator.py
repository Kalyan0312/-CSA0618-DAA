import random
from pathlib import Path
REG_NO="192525219"
NAME="Kalyana Krishnan A"
SEED=5219
SIZES=[1_000,10_000,100_000,1_000_000]
def generate_dataset(n):
    rng=random.Random(SEED+n)
    values=list(range(100_000_000+SEED*1_000+n,100_000_000+SEED*1_000+2*n))
    rng.shuffle(values)
    return values
if __name__=="__main__":
    for n in SIZES:
        values=generate_dataset(n)
        print(f"n={n:,} unique={len(set(values))==n} seed={SEED}")
    sample=generate_dataset(1000)[:100]
    (Path(__file__).resolve().parents[1]/"data"/"sample_1000.txt").write_text("\\n".join(map(str,sample))+"\\n")
