import csv, sys, time, random, platform
from pathlib import Path
from datetime import datetime
import matplotlib.pyplot as plt
sys.path.insert(0,str(Path(__file__).resolve().parent))
from algorithms import linear_search,binary_search_recursive,build_hash_index,hash_search
from dataset_generator import generate_dataset,SIZES,SEED,REG_NO,NAME
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"results"
def avg(a): return sum(a)/len(a)
def main():
    print("="*72)
    print(f"DAA A1 | Reg No: {REG_NO} | Name: {NAME}")
    print("System local date/time:",datetime.now().astimezone().isoformat(timespec="seconds"))
    print("Python:",platform.python_version(),"| Personal seed:",SEED)
    rows=[]
    for n in SIZES:
        records=generate_dataset(n); ordered=sorted(records)
        t=time.perf_counter(); index=build_hash_index(records); hash_build=time.perf_counter()-t
        t=time.perf_counter(); sorted(records); sort_s=time.perf_counter()-t
        q=100 if n<1_000_000 else 50
        rng=random.Random(SEED+n+17); keys=[records[rng.randrange(n)] for _ in range(q)]
        # Personal registration number and reg no + 1 are required absent-key cases.
        for key in [records[0],records[n//2],records[-1],int(REG_NO),int(REG_NO)+1]:
            li=linear_search(records,key); bi=binary_search_recursive(ordered,key); hi=hash_search(index,key)
            expected=key in records
            assert (li!=-1)==expected and (bi!=-1)==expected and (hi!=-1)==expected
            if li!=-1: assert records[li]==key
            if bi!=-1: assert ordered[bi]==key
            if hi!=-1: assert records[hi]==key
        lc=[]; bc=[]
        t=time.perf_counter()
        for k in keys:
            _,c=linear_search(records,k,True); lc.append(c)
        lin_s=(time.perf_counter()-t)/q
        t=time.perf_counter()
        for k in keys:
            _,c=binary_search_recursive(ordered,k,count=True); bc.append(c)
        bin_s=(time.perf_counter()-t)/q
        t=time.perf_counter()
        for k in keys: hash_search(index,k)
        hash_s=(time.perf_counter()-t)/q
        task12=""; count12=0
        if n==1_000_000:
            batch=[records[i] for i in range(50_000)]
            t=time.perf_counter(); count12=sum(hash_search(index,k)!=-1 for k in batch); task12=time.perf_counter()-t
            assert count12==50_000
            print(f"Task 12 revised-index benchmark: n={n:,}; searches=50,000; found={count12:,}; elapsed={task12:.6f}s")
        row={"n":n,"queries":q,"linear_us_per_query":round(lin_s*1e6,4),
             "linear_avg_comparisons":round(avg(lc),3),"binary_us_per_query":round(bin_s*1e6,4),
             "binary_avg_comparisons":round(avg(bc),3),"hash_us_per_query":round(hash_s*1e6,4),
             "sort_preprocess_seconds":round(sort_s,6),"hash_build_seconds":round(hash_build,6),
             "task12_50000_search_seconds":round(task12,6) if task12!="" else ""}
        rows.append(row)
        print(f"n={n:,} | linear={row['linear_us_per_query']:.2f} us / {row['linear_avg_comparisons']:.0f} comps | binary={row['binary_us_per_query']:.2f} us / {row['binary_avg_comparisons']:.1f} comps | hash={row['hash_us_per_query']:.3f} us | sort={sort_s:.5f}s | hash-build={hash_build:.5f}s")
    with (OUT/"results.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    ns=[r["n"] for r in rows]
    plt.figure()
    for key,label in [("linear_us_per_query","Iterative linear"),("binary_us_per_query","Recursive binary"),("hash_us_per_query","Hash table")]:
        plt.plot(ns,[r[key] for r in rows],marker="o",label=label)
    plt.xscale("log"); plt.yscale("log"); plt.xlabel("Number of records (n)"); plt.ylabel("Mean time per query (microseconds)")
    plt.title(f"Lookup time | Reg No {REG_NO}"); plt.legend(); plt.grid(True,which="both",alpha=.3); plt.tight_layout()
    plt.savefig(OUT/"graphs"/"lookup_time.png",dpi=180); plt.close()
    plt.figure()
    for key,label in [("sort_preprocess_seconds","Sort preprocessing"),("hash_build_seconds","Hash index construction")]:
        plt.plot(ns,[r[key] for r in rows],marker="o",label=label)
    plt.xscale("log"); plt.yscale("log"); plt.xlabel("Number of records (n)"); plt.ylabel("Preprocessing time (seconds)")
    plt.title(f"Preprocessing cost | Reg No {REG_NO}"); plt.legend(); plt.grid(True,which="both",alpha=.3); plt.tight_layout()
    plt.savefig(OUT/"graphs"/"preprocessing.png",dpi=180); plt.close()
    print("Correctness tests: PASS (first/middle/last, absent keys, personal reg no and reg no + 1)")
    print("CSV:",OUT/"results.csv"); print("Graphs:",OUT/"graphs")
if __name__=="__main__": main()
