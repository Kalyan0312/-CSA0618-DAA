def linear_search(records, key, count=False):
    c=0
    for i, value in enumerate(records):
        c += 1
        if value == key: return (i,c) if count else i
    return (-1,c) if count else -1

def binary_search_recursive(records, key, low=0, high=None, count=False):
    if high is None: high=len(records)-1
    if low>high: return (-1,0) if count else -1
    mid=(low+high)//2
    c=1
    if records[mid]==key: return (mid,c) if count else mid
    if key<records[mid]: result=binary_search_recursive(records,key,low,mid-1,count)
    else: result=binary_search_recursive(records,key,mid+1,high,count)
    if count:
        idx, child=result
        return idx,c+child
    return result

def build_hash_index(records):
    return {value:i for i,value in enumerate(records)}

def hash_search(index,key):
    return index.get(key,-1)
