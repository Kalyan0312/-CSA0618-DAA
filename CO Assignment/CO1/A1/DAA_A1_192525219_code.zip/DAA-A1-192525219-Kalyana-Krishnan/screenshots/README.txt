REQUIRED REAL SCREENSHOTS — CAPTURE BEFORE SUBMISSION
Do not submit fabricated or generated terminal screenshots.
Run `python src/benchmark.py` on your own computer and capture full terminal/IDE output with your registration number, name, and system date/time visible.
Required evidence:
1. task08_correctness_test.png — full run showing correctness PASS.
2. task09_runtime_1000.png
3. task09_runtime_10000.png
4. task09_runtime_100000.png
5. task09_runtime_1000000.png
6. task09_graphs.png — labelled graphs generated from your results.csv.
7. task12_50000_searches.png — output showing 50,000 successful lookups on 1,000,000 records.
Add captions in the report and ensure screenshot values match results.csv. Capture these yourself on the computer used for your final benchmark.
