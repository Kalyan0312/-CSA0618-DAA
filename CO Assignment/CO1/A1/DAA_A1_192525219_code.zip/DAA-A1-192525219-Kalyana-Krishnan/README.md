# DAA Assignment 1 — Student Record Search

- Student: Kalyana Krishnan A
- Registration number: 192525219
- Personal dataset seed: 5219 (last four digits of registration number)
- Algorithms: iterative linear search, recursive binary search, hash-table lookup
- Language: Python 3
- GitHub repository provided: https://github.com/Kalyan0312/-CSA0618-DAA

## Repository structure
- `report/DAA_A1_192525219.pdf` — final PDF report
- `src/algorithms.py` — three implementations
- `src/dataset_generator.py` — deterministic personalized data generator
- `src/benchmark.py` — correctness checks, timing, counters, CSV and graphs
- `data/` — small sample; larger datasets generated in memory
- `results/results.csv` and `results/graphs/` — experiment output
- `screenshots/` — genuine terminal captures to be added by student

## Run
Python 3.10+:
```bash
python -m pip install -r requirements.txt
python src/dataset_generator.py
python src/benchmark.py
```
The benchmark prints your name, registration number, local timestamp, all four data sizes, correctness results and the 50,000-query test on one million records. It generates the CSV and labelled graphs.

## Required personal cases
The tests include registration number 192525219 and 192525220. Both are absent from the generated synthetic key range, which is stated explicitly in the report.

## Screenshot and Git rules
Run this on your own computer and capture full terminal output showing name/reg no and date/time. Do not fabricate screenshots. Make at least five meaningful commits across the assignment week; never manufacture commit history. Place the final PDF in `report/` and create the Classroom zip after adding your genuine screenshots.
